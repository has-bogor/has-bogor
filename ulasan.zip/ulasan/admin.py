from django.contrib import admin
from ulasan.models import Ulasan
# Register your models here.

admin.site.register(Ulasan)
